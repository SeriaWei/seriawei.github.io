﻿$(function () {
    var widgetCreator = function () {

        var widgets = {
            "Widget.Header": function (target) {
                var data = getDefaultData(target);
                data.PartialView = "Widget.HTML";
                data.HTML = '<h2 style="text-align: center;">在这里输入你的标题</h2>';
                post(data, target);
            },
            "Widget.Line": function (target) {
                var data = getDefaultData(target);
                data.PartialView = "Widget.HTML";
                data.HTML = '<hr/>';
                post(data, target);
            },
            "Widget.CopyRight": function (target) {
                var data = getDefaultData(target);
                data.PartialView = "Widget.HTML";
                data.StyleClass = "footer";
                data.HTML = '<div id="footer">ZKEACMS是开源软件，提供免费下载学习使用<p>Copyright @&nbsp;2015 ZKEASOFT. All Rights Reserved | <a href="http://www.zkea.net/" target="_blank" rel="noopener">www.zkea.net</a></p></div>';
                post(data, target);
            },
            "Widget.HTML": function (target) {
                var data = getDefaultData(target);
                data.HTML = '<h2 style="text-align: center;">ZKEASOFT</h2><hr/><p>ZKEACMS是ZKEASOFT自主研发的，开源的建站系统，您可以使用它来做为您的企业网站，门户网站或者个人网站，博客，或用它做二次定制开发以满足您特定的需求。</p>';
                post(data, target);
            },
            "Widget.Navigation": function (target) {
                var data = getDefaultData(target);
                data.CustomerClass = "container";
                data.AlignClass = "navbar-left";
                data.Logo = "~/images/logo_zkea.png";
                data.RootID = "root";
                post(data, target);
            },
            "Widget.Carousel": function (target) {
                var data = getDefaultData(target);
                data["CarouselItems[0].TargetLink"] = 'http://www.zkea.net/zkeacms';
                data["CarouselItems[0].ImageUrl"] = '~/images/bg1.jpg';
                data["CarouselItems[0].Status"] = '1';

                data["CarouselItems[1].TargetLink"] = 'http://www.zkea.net/zkeacms';
                data["CarouselItems[1].ImageUrl"] = '~/images/bg2.jpg';
                data["CarouselItems[1].Status"] = '1';

                data["CarouselItems[2].TargetLink"] = 'http://www.zkea.net/zkeacms';
                data["CarouselItems[2].ImageUrl"] = '~/images/bg3.jpg';
                data["CarouselItems[2].Status"] = '1';
                post(data, target);
            },
            "Widget.Image": function (target) {
                var data = getDefaultData(target);
                data.ImageUrl = "~/images/30.jpg";
                post(data, target);
            },
            "Widget.Video": function (target) {
                var data = getDefaultData(target);
                //data.Url = "~/images/video.mp4";
                data.Code = "<iframe height=498 width=510 src='https://player.youku.com/embed/XMTYxNjU4OTgzMg==' frameborder=0 'allowfullscreen'></iframe>";
                post(data, target);
            },
            "Widget.Section": function (target) {
                var data = getDefaultData(target);
                data.FormView = "SectionWidgetForm";
                post(data, target);
            },
            "Widget.Message": function (target) {
                post(getDefaultData(target), target);
            },
            "Widget.MessageBox": function (target) {
                post(getDefaultData(target), target);
            },
            "Widget.Breadcrumb": function (target) {
                post(getDefaultData(target), target);
            },
            "Widget.ArticleList": function (target) {
                Easy.ShowUrlWindow({
                    url: '/Admin/ArticleType/Select',
                    width: 800,
                    onLoad: function (box) {
                        var win = this;
                        $(this.document).find("#confirm").click(function () {
                            var type = win.GetSelected();
                            if (type) {
                                box.close();
                                var data = getDefaultData(target);
                                data.ArticleTypeID = type;
                                data.DetailPageUrl = "~/article/detail";
                                data.PartialView = "Widget.ArticleList";
                                data.IsPageable = true;
                                data.PageSize = 5;
                                post(data, target);
                            }
                        });
                    },
                    zindex: 11
                });
            },
            "Widget.ArticleType": function (target) {
                Easy.ShowUrlWindow({
                    url: '/Admin/ArticleType/Select',
                    width: 800,
                    onLoad: function (box) {
                        var win = this;
                        $(this.document).find("#confirm").click(function () {
                            var type = win.GetSelected();
                            if (type) {
                                box.close();
                                var data = getDefaultData(target);
                                data.Title = "文章类别";
                                data.ArticleTypeID = type;
                                data.PartialView = "Widget.ArticleType";
                                post(data, target);
                            }

                        });
                    },
                    zindex: 11
                });
            },
            "Widget.ArticleSummary": function (target) {
                var data = getDefaultData(target);
                data.SubTitle = "ZKEACMS 简介";
                data.Style = "bs-callout-default";
                data.DetailLink = "/";
                data.Summary = '<p><a href="https://github.com/SeriaWei/ASP.NET-MVC-CMS" target="_blank" rel="noopener">ZKEACMS</a>是基于ASP.NET MVC4开发的开源CMS，提供免费下载学习使用。</p><p>ZKEACMS使用可视化编辑设计，所见即所得，可直接在页面上设计你要的页面。</p>';
                post(data, target);
            },
            "Widget.ProductList": function (target) {
                Easy.ShowUrlWindow({
                    url: '/Admin/ProductCategory/Select',
                    width: 800,
                    onLoad: function (box) {
                        var win = this;
                        $(this.document).find("#confirm").click(function () {
                            var type = win.GetSelected();
                            if (type) {
                                box.close();
                                var data = getDefaultData(target);
                                data.ProductCategoryID = type;
                                data.DetailPageUrl = "~/product/detail";
                                data.PartialView = "Widget.ProductList";
                                data.IsPageable = true;
                                data.PageSize = 9;
                                data.Columns = "col-xs-12 col-sm-6 col-md-4";
                                post(data, target);
                            }
                        });
                    },
                    zindex: 11
                });
            },
            "Widget.ProductCategory": function (target) {
                Easy.ShowUrlWindow({
                    url: '/Admin/ProductCategory/Select',
                    width: 800,
                    onLoad: function (box) {
                        var win = this;
                        $(this.document).find("#confirm").click(function () {
                            var type = win.GetSelected();
                            if (type) {
                                box.close();
                                var data = getDefaultData(target);
                                data.Title = "产品类别";
                                data.ProductCategoryID = type;
                                data.PartialView = "Widget.ProductCategory";
                                post(data, target);
                            }

                        });
                    },
                    zindex: 11
                });
            },
        }
        function getDefaultData(target) {
            return {
                "PageID": $(target).data("page-id"),
                "ZoneID": $(target).data("zone-id"),
                "AssemblyName": $(target).data("assembly"),
                "ServiceTypeName": $(target).data("service-type"),
                "ViewModelTypeName": $(target).data("viewmodel-type"),
                "PartialView": $(target).data("widget"),
                "WidgetName": $(target).data("name")
            };
        }
        function reSort(target) {
            var widgets = [];
            var zone = $(target).closest(".zone");
            zone.find(".widget-design").each(function (i, ui) {
                widgets.push({
                    ID: $(ui).data("widgetid"),
                    ZoneId: $(".zoneId", zone).val(),
                    Position: i + 1
                });
            });
            $.ajax({
                type: "POST",
                url: $("#save-widget-zone-url").val(),
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                async: false,
                data: JSON.stringify(widgets),
                success: function () {
                    $(".widget.widget-design", zone).editor();
                }
            });
        }
        function post(data, target) {
            $.ajax({
                type: "POST",
                url: $(target).data("action"),
                dataType: 'html',
                data: data,
                success: function (data) {
                    $(data).insertBefore($(target).closest(".zoneName"));
                    reSort(target);
                }
            });
        }

        widgets[$(this).data("widget")](this);
    };
    $(document).on("click", ".zoneName .dropdown-menu a.add-widget", widgetCreator);

    function refreshWidget(widgetId, includeSource) {
        $(".image-uploader").appendTo(document.body);
        $.post("/Admin/Widget/PartWidget", { widgetId: widgetId, includeSource: includeSource }, function (html) {
            $("#widget_" + widgetId).parent().replaceWith(html);
            $("#widget_" + widgetId).editor();
        });

        $(document).trigger("widget.changed");
    }
    $(document).on("widget.changed", function () {
        $(".deletor").hide();
        $(".zkea-editor").removeClass("show");
    }).on("click", function () { $(".deletor").hide(); });
    $(document).on("click", ".section .copy", function () {
        var groupId = $(this).closest(".section").find(".copy-group").last().data("id");
        var widgetId = $(this).closest(".widget.widget-design").data("widgetid");
        var data = { GroupID: groupId, Groups: [] }
        $(this).closest(".section").find(".copy-group").each(function () {
            var id = $("a.remove", this).data("id");
            if (id != groupId) {
                data.Groups.push({ ID: id });
            }
        });
        $.ajax({
            type: "POST",
            url: "/Admin/SectionGroup/CopyGroup",
            dataType: 'json',
            contentType: "application/json;charset=utf-8",
            data: JSON.stringify(data),
            success: function (data) {
                refreshWidget(widgetId, false);
            }
        });
    });
    $(document).on("click", ".section .group-toolbar .remove", function () {
        if ($(this).closest(".row").children().size() > 1) {
            var groupId = $(this).data("id");
            var widgetId = $(this).closest(".widget.widget-design").data("widgetid");
            $.post("/Admin/SectionGroup/RemoveGroup", { groupId: groupId }, function () {
                refreshWidget(widgetId, false);
            });
        } else {
            $(this).closest(".widget.widget-design").find(".zoneToolbar .tools .delete").trigger("click");
        }
    });
    $(document).on("click", ".group-actions .row.border", function () {
        var widgetId = $(this).closest('.widget.widget-design').data("widgetid");
        $(".row.border.actived", $(this).closest(".dropdown-menu")).removeClass("actived");
        $(this).addClass("actived");
        var sectionGroups = $(".copy-group", $(this).closest(".section"));
        var groups = [];
        setters = $(".col", this);
        sectionGroups.each(function (i) {
            groups[i] = {};
            groups[i].PercentWidth = setters.eq(i).data("col");
            groups[i].ID = $(this).data("id");
        });
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: "/admin/SectionGroup/SplitColumn",
            data: JSON.stringify(groups),
            contentType: 'application/json; charset=utf-8',
            async: false,
            success: function (data) {
                refreshWidget(widgetId, false);
            }
        });
    });
    $(document).on("click", ".splitor .well", function () {
        var widgetId = $(this).closest('.widget.widget-design').data("widgetid");
        var sectionGroups = $(this).data("col").split(",");
        var groups = [];
        setters = $(".col", this);
        $.each(sectionGroups, function (i) {
            groups[i] = {};
            groups[i].SectionWidgetId = widgetId;
            groups[i].GroupName = "组" + (i + 1);
            groups[i].Order = (i + 1);
            groups[i].PercentWidth = this;
            groups[i].PartialView = "SectionTemplate.Default";
            groups[i].ID = null;
        });
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: "/admin/SectionGroup/SplitColumn",
            data: JSON.stringify(groups),
            contentType: 'application/json; charset=utf-8',
            async: false,
            success: function (data) {
                refreshWidget(widgetId, false);
            }
        });
    });
    $(document).on("click", ".section .group-toolbar .add-content", function () {
        var widgetId = $(this).closest('.widget.widget-design').data("widgetid");
        $.post("/admin/SectionGroup/AddContent", { widgetId: widgetId, groupId: $(this).closest(".copy-group").data("id"), contentType: $(this).data("content") }, function () {
            refreshWidget(widgetId, false);
        });
    });
    $(document).on("mouseenter", ".section [property=true]", function () {
        var widgetId = $(this).closest('.widget.widget-design').data("widgetid");
        var deletor = $(".deletor");
        if (deletor.size() == 0) {
            deletor = $('<div class="deletor"><i class="glyphicon glyphicon-remove"></i>删除？</div>');
            deletor.on("click", function () {
                var wid = $(this).data("widget-id");
                $.post("/admin/SectionGroup/RemoveContent", { id: $(this).data("id") }, function () {
                    refreshWidget(wid, false);
                })
            });
            deletor.appendTo(document.body);
        }
        deletor.show();
        deletor.data("id", $(this).data("id"));
        deletor.data("widget-id", widgetId);
        deletor.css("left", $(this).offset().left - deletor.outerWidth() - 8);
        deletor.css("top", $(this).offset().top);
    });

    $(".zone").sortable({
        items: ">div:not(.zoneName)",
        placeholder: "sorting",
        handle: ".sort-handle",
        tolerance: "pointer",
        connectWith: ".zone",
        stop: function (event, ui) {
            var target = ui.item.parent();
            if (ui.item.data("add")) {
                $.ajax({
                    type: "POST",
                    url: $("#append-widget-url").val(),
                    dataType: 'html',
                    async: false,
                    data: {
                        ID: ui.item.data("id"),
                        ZoneID: $("input.zoneId", this).val(),
                        PageID: $("#pageId").val(),
                        AssemblyName: ui.item.data("assemblyname"),
                        ServiceTypeName: ui.item.data("servicetypename"),
                        Position: 1
                    },
                    success: function (data) {
                        ui.item.replaceWith(data);
                        $(".widget.widget-design", target).editor();
                        $(document).trigger("widget.changed");
                    }
                });
            }
            var widgets = [];
            target.find(".widget-design").each(function (i, ui) {
                widgets.push({
                    ID: $(ui).data("widgetid"),
                    ZoneId: $(".zoneId", target).val(),
                    Position: i + 1
                });
            });
            $.ajax({
                type: "POST",
                url: $("#save-widget-zone-url").val(),
                dataType: 'json',
                contentType: "application/json;charset=utf-8",
                async: false,
                data: JSON.stringify(widgets),
                success: function () {
                }
            });
            return true;
        }
    });

    $(".templates ul li").draggable({ helper: "clone", connectToSortable: ".zone" });
    $(document).on("click", ".zoneToolbar .delete", function () {
        var th = $(this);
        $.post(th.data("url"), { ID: th.data("id") }, function (data) {
            if (data) {
                $("#widget_" + data).parent().remove();
                $(document).trigger("widget.changed");
            }
        }, "json");
    });
    $(document).on("click", ".templates .tool-open", function () {
        $(this).parent().toggleClass("active");
    }).on("click", ".templates .delete-template", function () {
        var th = $(this);
        Easy.ShowMessageBox("提示", "确定要删除该模板吗？", function () {
            $.post(th.data("url"), { Id: th.data("id") }, function (data) {
                if (data) {
                    $("#template_" + data).remove();
                }
            }, "json");
        }, true, 10);
    }).on("click", ".upload-template", function () {
        $("#template-file").trigger("click");
    }).on("change", "#template-file", function () {
        $("#template-form").submit();
    }).on("click", ".zoneToolbar .toggle-widget-class", function () {
        var clas = $(this).data("class");
        $(this).closest(".widget").toggleClass(clas);
        $.post($(this).data("action"), { clas: clas }, function () {
        });
    }).on("click", ".zoneToolbar .custom-style-editor", function () {
        $(".custom-style-target").removeClass("custom-style-target");
        var url = $(this).data("action");
        var styleTarget = $(this).closest(".widget").parent();
        styleTarget.toggleClass("custom-style-target");
        window.top.Easy.ShowUrlWindow({
            url: '/js/StyleEditor/index.html',
            width: 1024,
            title: "编辑样式",
            onLoad: function (box) {
                box.addClass("loaded");
            },
            callBack: function () {
                $.post(url, { style: styleTarget.attr("style") }, function () {
                });
            },
            isDialog: false
        });
        $(".WeiWindow.BoxShadow").addClass("StyleEditor");
    }).on("click", ".copy-widget", function () {
        $.post($(this).data("action"), function (data) {
            Easy.MessageTip.Show(data.message);
        });
    }).on("click", ".paste-widget", function () {
        var zone = $(this).closest(".zone");
        if (!zone.data("pasting")) {
            zone.data("pasting", true);
            $.post($(this).attr("href"), { Position: $(".widget", zone).size() + 1 }, function (html) {
                zone.append(html);
                zone.data("pasting", false);
            }, "html");
        }
        return false;
    });
    $(".helper").click(function () {
        $("#containers").toggleClass($(this).data("class"));
    });
    if ($(window).width() > 1600) {
        $(".templates").addClass("active");
    }

    $(".widget.widget-design").editor();
});