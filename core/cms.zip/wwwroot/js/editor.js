﻿/*!
 * http://www.zkea.net/
 * Copyright 2017 ZKEASOFT
 * http://www.zkea.net/licenses
 */
jQuery.fn.extend({
    editor: function (option) {
        /*----------------Processing-------------------*/
        var processing = null;
        function initProcessing() {
            if (processing == null) {
                processing = $(".processing");
            }
            if (processing.size() == 0) {
                processing = $("<div></div>").addClass("processing");
                $(document.body).append(processing);
            }
        }
        function showProcessing() {
            initProcessing();
            processing.addClass("show");
        }
        function removeProcessing() {
            initProcessing();
            processing.removeClass("show");
        }
        /*----------------Uploader-------------------*/
        var uploader = null;
        function initUploader() {
            if (uploader == null) {
                uploader = $(".zkea-editor.image-uploader");
            }
            if (uploader.size() == 0) {
                uploader = $('<div class="zkea-editor image-uploader"><input type="file" name="image" /></div>');
                uploader.on("click", function (e) {
                    if ($(e.target).hasClass("image-uploader")) {
                        $("input", this).trigger("click");
                    }
                });
                //uploader.on("mouseleave", removeUploader);
                uploader.on("change", "input", function () {
                    showProcessing();
                    var target = $(this).data("target");
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "/admin/media/Upload");
                    xhr.onload = function (data) {
                        removeProcessing();
                        var result = JSON.parse(data.target.response);
                        if (result.id) {
                            target.attr("src", result.url);
                            target.trigger("content-changed");
                            uploader.trigger("mouseleave");
                        }
                    }
                    xhr.onerror = function () {
                        alert("上传失败");
                    }
                    var formData = new FormData();
                    formData.append('file', this.files[0]);
                    formData.append("folder", "图片");
                    xhr.send(formData);
                    $(this).remove();
                    uploader.append('<input type="file" name="image" />');
                });
                $(document.body).append(uploader);
            }
        }
        function invokeUploader(container) {
            initUploader();
            uploader.appendTo($(this).closest(".widget.widget-design"));
            uploader.css("left", $(this).offset().left + ($(this).width() / 2) - (uploader.width() / 2));
            uploader.css("top", $(this).offset().top + ($(this).height() / 2) - (uploader.height() / 2));
            //uploader.width($(this).width());
            //uploader.height($(this).height());
            uploader.addClass("show");
            $("input", uploader).data("target", $(this));
        }
        function removeUploader() {
            if (uploader != null && uploader.hasClass("show")) {
                uploader.removeClass("show");
            }
        };
        /*----------------Editor-------------------*/
        var editBar = null;
        function initEditBar() {
            if (editBar == null) {
                editBar = $(".zkea-editor.editor-toolbar");
            }
            if (editBar.size() == 0) {
                editBar = $('<div class="zkea-editor editor-toolbar">\
            <div class="icons clearfix">\
                <i title="文本等级" class="icon-text toggle-menu"><ul class="menu tag"><li tag="P">段落</li><li tag="H1">标题 1</li><li tag="H2">标题 2</li><li tag="H3">标题 3</li><li tag="H4">标题 4</li><li tag="H5">标题 5</li><li tag="H6">标题 6</li></ul></i>\
                <i title="字体大小" class="icon-font-size toggle-menu"><ul class="menu font"><li size="1">最小</li><li size="2">偏小</li><li size="3">普通</li><li size="4">略大</li><li size="5">偏大</li><li size="6">更大</li><li size="7">最大</li></ul></i>\
                <i title="加粗" class="icon-bold command" data-command="bold"></i>\
                <i title="斜体" class="icon-italic command" data-command="italic"></i>\
                <i title="下划线" class="icon-underline command" data-command="underline"></i>\
                <i title="左对齐" class="icon-justifyleft command" data-command="justifyLeft"></i>\
                <i title="居中" class="icon-justifycenter command" data-command="justifyCenter"></i>\
                <i title="右对齐" class="icon-justifyright command" data-command="justifyRight"></i>\
                <i title="增加缩进" class="icon-indent command" data-command="indent"></i>\
                <i title="减少缩进" class="icon-outdent command" data-command="outdent"></i>\
                <i title="链接" class="icon-link"></i>\
                <i title="取消链接" class="icon-unlink"></i>\
                <i title="无序列表" class="icon-bulletedlist command" data-command="insertUnorderedList"></i>\
                <i title="有序列表" class="icon-numberedlist command" data-command="insertOrderedList"></i>\
                <i title="字体颜色" class="icon-color toggle-menu"><ul class="menu color clearfix"><li class="color-fff"></li><li class="color-555"></li><li class="color-000"></li><li class="color-816354"></li><li class="color-ff4d4d"></li><li class="color-ffa64d"></li><li class="color-9cce06"></li><li class="color-26c9ff"></li></ul></i>\
                <i title="插入图片" class="icon-image command" data-command="insertImage" data-val="/images/01.jpg"></i>\
                <i title="撤销" class="icon-undo command" data-command="undo"></i>\
                <i title="重做" class="icon-redo command" data-command="redo"></i>\
                <i title="清除格式" class="icon-clean command" data-command="removeFormat"></i>\
            </div>\
            <div class="inputs">\
                <input type="text" placeholder="输入网址如:http://www.zkea.net" />\
                <span class="confirm glyphicon glyphicon-ok"></span>\
            </div></div>');
                $("input", editBar).autoPageLink();
                editBar.on("mousedown", "i", function () { return false; })
                editBar.on("click", "i", function (e) {
                    var hasClass = $(".menu", this).hasClass("show");
                    $(".menu", editBar).removeClass("show");
                    if (!hasClass) {
                        $(".menu", this).addClass("show");
                    }
                    if (!$(e.target).hasClass("icon-link") && $(".inputs", editBar).hasClass("show")) {
                        $(".icon-link", editBar).trigger("click");
                    }
                });
                editBar.on("click", ".menu.tag li", function () {
                    document.execCommand("formatBlock", false, $(this).attr("tag"));
                    $(this).closest(".menu").trigger("click");
                    $(editBar.data("target")).trigger("content-changed");
                    $(this).siblings().removeClass("active");
                    $(this).addClass("active");
                    return false;
                });
                editBar.on("click", ".menu.font li", function () {
                    document.execCommand("fontSize", false, $(this).attr("size"));
                    $(this).closest(".menu").trigger("click");
                    $(editBar.data("target")).trigger("content-changed");
                    $(this).siblings().removeClass("active");
                    $(this).addClass("active");
                    return false;
                });
                editBar.on("click", ".menu.color li", function () {
                    document.execCommand("foreColor", false, $(this).attr("class").replace("color-", "#"));
                    $(this).closest(".menu").trigger("click");
                    $(editBar.data("target")).trigger("content-changed");
                    return false;
                });
                editBar.on("click", ".command", function () {
                    document.execCommand($(this).data("command"), false, $(this).data("val"));
                    $(editBar.data("target")).trigger("content-changed");
                    return false;
                });
                editBar.on("click", ".icon-link", function () {
                    if (!$(".inputs", editBar).hasClass("show")) {
                        $(".inputs", editBar).addClass("show");
                        if (window.getSelection) {
                            sel = window.getSelection();
                            if (sel.getRangeAt && sel.rangeCount) {
                                var ranges = [];
                                for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                                    ranges.push(sel.getRangeAt(i));
                                }
                                editBar.data("selection", ranges);
                            }
                        } else if (document.selection && document.selection.createRange) {
                            editBar.data("selection", document.selection.createRange());
                        }
                        $("input", editBar).focus();
                    } else {
                        $(".inputs", editBar).removeClass("show");
                        var savedSel = editBar.data("selection");
                        if (savedSel && savedSel.length > 0) {
                            if (window.getSelection) {
                                sel = window.getSelection();
                                sel.removeAllRanges();
                                for (var i = 0, len = savedSel.length; i < len; ++i) {
                                    sel.addRange(savedSel[i]);
                                }
                            } else if (document.selection && savedSel.select) {
                                savedSel.select();
                            }

                        }
                    }
                    return false;
                });
                editBar.on("click", ".icon-unlink", function () {
                    if (!document.execCommand("unlink", false, null)) {
                        var linkNode = getSelectionStartNode();
                        if (linkNode.nodeName == "A" || linkNode.nodeName == "a") {
                            $(linkNode).replaceWith($(linkNode).text());
                        }
                    }
                    $(".icon-link.active", editBar).removeClass("active");
                    $(editBar.data("target")).trigger("content-changed");
                    return false;
                });
                editBar.on("click", function () { return false; });
                editBar.on("click", ".confirm", function () {
                    var e = $.Event('keyup');
                    e.which = 13;
                    e.keyCode = 13;
                    $(this).siblings("input").trigger(e);
                });
                editBar.on("keyup", "input", function (e) {

                    if (e.keyCode == 13) {
                        var value = fixHref($(this).val());
                        var savedSel = editBar.data("selection");
                        if (savedSel && savedSel.length > 0) {
                            if (window.getSelection) {
                                sel = window.getSelection();
                                sel.removeAllRanges();
                                for (var i = 0, len = savedSel.length; i < len; ++i) {
                                    sel.addRange(savedSel[i]);
                                }
                            } else if (document.selection && savedSel.select) {
                                savedSel.select();
                            }
                            var node = getSelectionStartNode();
                            if (node.nodeName == "A" || node.nodeName == "a") {
                                node.href = value;
                            } else {
                                document.execCommand("createLink", false, value);
                            }
                        }
                        if (value) {
                            $(".icon-link", editBar).addClass("active");
                        } else {
                            $(".icon-link", editBar).removeClass("active");
                        }
                        $(".inputs", editBar).removeClass("show");
                        $(editBar.data("target")).trigger("content-changed");
                    }
                });
                editBar.on("mouseup", function () { return false });
                editBar.appendTo(document.body);
            }
        }
        function invokeEditBar(e) {
            initEditBar();
            clearTimeout(this.cti);
            this.cti = setTimeout(function () {
                clearTimeout(editBar.data("CloseTimer"));
                var editPlace = $(e.target).closest("[contenteditable=true]");
                var position = { left: 0, top: 0 };
                if (window.getSelection().isCollapsed) {
                    position = { left: editPlace.offset().left, top: editPlace.offset().top };
                    position.top -= 1 * editBar.outerHeight();
                } else {
                    position = getSelectionPosition.call(e.target);
                    position.top -= 1.5 * editBar.outerHeight();
                    position.left = position.left - editBar.width() / 3;
                }

                var left = position.left;
                if (left < 20) {
                    left = 20;
                }
                if (left + editBar.width() + 20 > $(window).width()) {
                    left = $(window).width() - editBar.width() - 20;
                }
                position.left = left;

                editBar.css("left", position.left);
                editBar.css("top", position.top);
                $(".widget.widget-design.hideToolBar").removeClass("hideToolBar");
                var node = getSelectionStartNode();
                $(".show", editBar).removeClass("show");
                $(".active", editBar).removeClass("active");
                $("input", editBar).val("");
                var node = getSelectionStartNode();
                $("li[tag=" + node.nodeName + "]", editBar).addClass("active");
                node = node.nodeName == "A" ? node : node.parentNode;
                if (node.nodeName == "A" && node.href) {
                    $(".icon-link", editBar).addClass("active");
                    $("input", editBar).val($(node).attr("href"));
                }
                $(".inputs", editBar).removeClass("show");
                editBar.data("target", editPlace);
                editBar.addClass("show");
                removeLinkEditor();
                $(e.target).closest(".widget.widget-design").addClass("hideToolBar");

            }, 50);
        }
        function removeEditBar() {
            var sid = setTimeout(function () {
                if (editBar != null && editBar.hasClass("show")) {
                    editBar.removeClass("show");
                    $(".widget.widget-design.hideToolBar").removeClass("hideToolBar");
                }
            }, 100);
            if (editBar != null && editBar.size() != 0) {
                editBar.data("CloseTimer", sid);
            }
        }
        /*----------------LinkEditor-------------------*/
        var linkEditor = null;
        function initLinkEditor() {
            if (linkEditor == null) {
                linkEditor = $(".zkea-editor.editor-link");
            }
            if (linkEditor.size() == 0) {
                linkEditor = $('<div class="zkea-editor editor-link"><div class="label">链接到：</div><div class="inputs"><input type= "text" placeholder= "输入网址如:http://www.zkea.net"/><span class="confirm glyphicon glyphicon-ok"></span></div></div>');
                $("input", linkEditor).autoPageLink();
                linkEditor.on("click", ".confirm", function () {
                    $(this).siblings("input").trigger("change");
                    removeLinkEditor();
                });
                linkEditor.on("change", "input", function () {
                    var value = fixHref($(this).val());
                    $(linkEditor.data("target")).attr("href", value).trigger("content-changed");
                });
                linkEditor.on("mouseup", function () { return false; });
                linkEditor.appendTo(document.body);
            }
        }
        function invokeLinkEditor() {
            initLinkEditor();
            linkEditor.css("left", $(this).offset().left);
            linkEditor.css("top", $(this).offset().top - linkEditor.outerHeight() - 10);
            linkEditor.data("target", this);
            linkEditor.addClass("show");
            $("input", linkEditor).val($(this).attr("href"));
            removeEditBar();
            $(this).closest(".widget.widget-design").addClass("hideToolBar");
            return false;
        }
        function removeLinkEditor() {
            if (linkEditor != null && linkEditor.hasClass("show")) {
                linkEditor.removeClass("show");
                $(".widget.widget-design.hideToolBar").removeClass("hideToolBar");
            }
        }

        /*----------------Helpers-------------------*/
        function fixHref(value) {
            if (value) {
                value = value.toLowerCase();
                if (value.startsWith("www.")) {
                    value = "http://" + value;
                }
                else if (value.startsWith("~/")) {
                    value = value.replace("~/", "/");
                }
            }
            return value;
        }
        var getSelectionPosition = function () {
            //other https://stackoverflow.com/questions/1589721/how-can-i-position-an-element-next-to-user-text-selection/1589912#1589912
            var range;
            if (document.selection && document.selection.createRange) {
                range = document.selection.createRange();
            } else if (window.getSelection) {
                sel = window.getSelection();
                if (sel.getRangeAt) {
                    range = sel.getRangeAt(0);
                } else {
                    range = document.createRange();
                    range.setStart(sel.anchorNode, sel.anchorOffset);
                    range.setEnd(sel.focusNode, sel.focusOffset);
                    if (range.collapsed !== sel.isCollapsed) {
                        range.setStart(sel.focusNode, sel.focusOffset);
                        range.setEnd(sel.anchorNode, sel.anchorOffset);
                    }
                }

            }
            //range.collapse(true);
            var rect = range.getBoundingClientRect();
            if (rect.left == 0 && rect.top == 0) {
                return { left: $(this).offset().left, top: $(this).offset().top };
            }
            return { left: rect.left, top: window.pageYOffset + rect.top };

        };
        function getSelectionNode() {
            var node, selection;
            if (window.getSelection) {
                selection = getSelection();
                node = selection.anchorNode;
            }
            if (!node && document.selection) {
                selection = document.selection;
                var range = selection.getRangeAt ? selection.getRangeAt(0) : selection.createRange();
                node = range.commonAncestorContainer ? range.commonAncestorContainer :
                    range.parentElement ? range.parentElement() : range.item(0);
            }
            return node;
        }
        function getSelectionStartNode() {
            var node = getSelectionNode();
            if (node) {
                return (node.nodeName == "#text" ? node.parentNode : node);
            }
        }
        if (!$(document).data("editor-dispose")) {
            $(document).data("editor-dispose", true);
            initEditBar();
            initLinkEditor();
            initProcessing();
            $(document).on("mouseup", function (e) {
                removeEditBar();
                removeLinkEditor();
            });
        }
        $(this).each(function () {
            var self = $(this);
            if (self.data("init")) {
                return;
            }
            self.data("init", true);
            $("[property=true][method=html]", self).attr("contenteditable", true).on("mouseup", invokeEditBar).on("keyup", function (e) {
                if (e.keyCode == 13) {
                    document.execCommand("formatBlock", false, "p");
                    document.execCommand("removeformat", false, null);
                }
            });
            $("[property=true][method=text]", self).attr("contenteditable", true).on("keydown", function (e) {
                if (e.keyCode == 13) {
                    return false;
                }
            }).on("click", function () { $(this).closest(".widget.widget-design").addClass("hideToolBar"); }).on("blur", function () { $(this).closest(".widget.widget-design").removeClass("hideToolBar"); });
            $("a[property=true]", self).on("click", invokeLinkEditor);
            function saveContent() {

                var contentPart = [];
                $("[property=true]", self).each(function () {
                    var property = $(this).data("property");
                    var method = $(this).attr("method");
                    var para = $(this).attr("para");
                    id = $(this).data("id") || self.data("widgetid");
                    url = $(this).data("url") || self.data("url");
                    var value = null;
                    if (para) {
                        value = $.trim($(this)[method](para));
                    } else {
                        value = $.trim($(this)[method]());
                    }
                    if (id && url) {
                        var existsGroup = false;
                        $.each(contentPart, function () {
                            if (this.Url == url) {
                                existsGroup = true;
                                var existsContent = false;
                                $.each(this.Contents, function () {
                                    if (this.ID == id) {
                                        existsContent = true;
                                        this.Properties.push(property);
                                        this.Contents.push(value);
                                    }
                                });
                                if (!existsContent) {
                                    this.Contents.push({ ID: id, Properties: [property], Contents: [value] })
                                }
                            }
                        });
                        if (!existsGroup) {
                            contentPart.push({ Url: url, Contents: [{ ID: id, Properties: [property], Contents: [value] }] });
                        }
                    }
                });

                function popSaving() {
                    showProcessing();
                    var content = contentPart.pop();
                    if (content) {
                        $.ajax({
                            url: content.Url,
                            type: 'POST',
                            data: JSON.stringify(content.Contents),
                            contentType: "application/json;charset=utf-8",
                            dataType: 'json',
                            success: popSaving
                        });
                    } else {
                        removeProcessing();
                    }
                }
                popSaving();
                return false;
            }
            self.on("keyup", function () {
                Easy.Processor(saveContent, 1000);
            });
            $(this).on("mouseenter", "img[property=true]", invokeUploader);
            $("[property=true][method=html]", self).on("mouseenter", "img", invokeUploader);
            $(this).on("content-changed", function () { Easy.Processor(saveContent, 1000); });
        });
        //$("img",this).resizable();
    },
    autoPageLink: function () {
        var process = 0;
        $(this).on("keydown", function (e) {
            if (e.keyCode == 38 || e.keyCode == 40) {
                return false;
            }
        });
        $(this).on("blur", function () {
            $("#autoPageLink").remove();
        });
        $(this).on("keyup", function (e) {
            var target = this;
            function getPageLink() {
                var pageLink = $("#autoPageLink");
                if (pageLink.size() == 0) {
                    pageLink = $('<ul id="autoPageLink" class="dropdown-menu"></ul>');
                    pageLink.css("border-top-left-radius", "0");
                    pageLink.css("border-top-right-radius", "0");
                    pageLink.css("margin-top", "0");
                    pageLink.css("max-width", $(target).outerWidth());
                    pageLink.on("mousedown", "li", function () {
                        return false;
                    });
                    pageLink.on("mouseup", "li", function () {
                        return false;
                    });
                    pageLink.on("click", "li", function () {
                        var val = $(this).data("val");
                        $(target).val(val);
                        pageLink.remove();
                        return false;
                    });
                    pageLink.appendTo(document.body);
                }
                return pageLink;
            }
            if (e.keyCode == 38) {
                var pageLink = getPageLink();
                if (pageLink.children().size() > 0) {
                    var currentIndex = $(".active", pageLink).index();
                    currentIndex--;
                    if (currentIndex >= 0) {
                        $(".active", pageLink).removeClass("active");
                        $("li:eq(" + currentIndex + ")", pageLink).addClass("active");
                    }
                    return false;
                }
            }
            else if (e.keyCode == 40) {
                var pageLink = getPageLink();
                if (pageLink.children().size() > 0) {
                    var currentIndex = $(".active", pageLink).index();
                    currentIndex++;
                    if (currentIndex < pageLink.children().size()) {
                        $(".active", pageLink).removeClass("active");
                        $("li:eq(" + currentIndex + ")", pageLink).addClass("active");
                    }
                    return false;
                }

            }
            else if (e.keyCode == 13) {
                var pageLink = getPageLink();
                if (pageLink.children().size() > 0) {
                    $(this).val(pageLink.find(".active").data("val")).trigger("change");
                    pageLink.remove();
                    return false;
                }
                return true;
            }
            function search() {
                if ($(target).val()) {
                    var left = $(target).offset().left;
                    var top = $(target).offset().top + $(target).outerHeight();
                    $.get("/admin/page/search", { q: $(target).val() }, function (data) {
                        var pageLink = getPageLink().empty();
                        if (data && data.length > 0) {
                            $.each(data, function (i) {
                                pageLink.append('<li data-val="' + this.url + '"><a href="javascript:void(0)">' + this.url + '<small class="small">' + (this.title || '') + '</small></a></li>');
                            });
                            pageLink.children().first().addClass("active");
                            pageLink.css("left", left);
                            pageLink.css("top", top);
                            pageLink.show();
                        } else {
                            pageLink.remove();
                        }
                    });
                }
            }
            clearTimeout(process);
            process = setTimeout(search, 500);
        });
    }
});