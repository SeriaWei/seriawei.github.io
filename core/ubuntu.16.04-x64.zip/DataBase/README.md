# ZKEACMS Database
## MsSql
Use Build.cmd to create the database.
![create](https://user-images.githubusercontent.com/6006218/30580006-a9c9507c-9d4d-11e7-9fcc-8a3eb40e2ffd.gif)

## MySql
Use the script under MySql to create the database.

## Sqlite
Use the tool Export.cmd under Sqlite folder to generate the script from MsSql. Then use the script to create sqlite database.
